//1

function first(arr, number) {
  let index = 0;
  for (let i = 0; i < arr.length; i++) {
    if (number === arr[i]) {
      index++;
    }
  }

  return index;
}

console.log(first([1, 2, 2, 2, 2, 3, 2], 2));

//2

function second(arr) {
  let newArr = [];
  for (let i = 0; i <= arr.length - 1; i++) {
    if (arr[i] % 2 === 0) {
      newArr.push(arr[i]);
    }
  }

  let uniqueArr = [...new Set(newArr)];
  return uniqueArr;
}

console.log(second([1, 2, 2, 2, 2, 3, 4]));

//3

function arrToObj(arr) {
  let count = {};

  for (let i = 0; i <= arr.length - 1; i++) {
    let element = arr[i];

    if (count[element]) {
      count[element]++;
    } else {
      count[element] = 1;
    }
  }

  return count;
}

console.log(arrToObj(["A", "B", "C", "A", "A", "C"]));

//4

function shallowClone(obj) {
  //     const newObj = {}
  //     Object.keys(obj).forEach((key) => {
  //         newObj[key] = obj[key]
  //     })
  // return newObj

  let cloneObj = { ...obj };
  return cloneObj;
}

console.log(shallowClone({ a: 1, b: 2 }));

//5

function deepClone(obj) {
  let cloneObj = JSON.parse(JSON.stringify(obj));
  return cloneObj;

  //to-do
}

console.log(deepClone({ a: 1, b: 2 }));

//6

function executorFunction(arr, validate) {
  let index = 0;
  arr.forEach((element) => {
    if (validate(element)) {
      index++;
    }
  });

  if (index === arr.length) {
    console.log("VALID");
  } else {
    console.log("NOT VALID");
  }
}

function validate(e) {
  return e % 2 === 0;
}

executorFunction([2, 2, 6, 4, 8], validate);

//7

function validateKeys(obj, arr) {
  let keys = Object.keys(obj);
  let isFound = (element) => arr.includes(element);

  return keys.every(isFound);
}

console.log(validateKeys({ name: "Steve", age: 23 }, ["name", "age"]));

//8

let validElements = (arr, validateEven) => {
  let newArr = [];

  arr.forEach((element) => {
    if (validateEven(element)) {
      newArr.push(element);
    }
  });
  return newArr;
};

let validateEven = (e) => {
  return e % 2 === 0;
};

console.log(validElements([1, 2, 3, 4, 5, 6, 8, 7], validateEven));

//9

const validEven = (element) => element % 2 !== 0;
const validSmaller = (element) => element < 10;

const funcsArray = [validEven, validSmaller];

const allValidElements = (arr, funcsArr) => {
  return arr.every((element) => {
    return funcsArr.every((xx) => {
      if (xx(element)) {
        return true;
      }
      return false;
    });

    // funcsArr.every((validateFunction) => validateFunction(element));
  });
};

// const allValidElements(arr, funcsArray) => arr.every((e) => funcsArr.every((validateFunction) => validateFunction(element)))

console.log(allValidElements([1, 3, 5, 7, 9], funcsArray));

//10

const diffValues = (arr1, arr2) => {
  let arrDiffValues = [];
  for (let i = 0; i < arr1.length; i++) {
      if (arr1[i] != arr2[i]) {
        arrDiffValues.push(arr1[i]);
      }
  }

  return arrDiffValues;
};

console.log(diffValues([1, 3, 1, 3, 5, 7, 9, 11], [1, 3, 1, 8, 10, 10]));
